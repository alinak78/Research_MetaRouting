"""Self-contained numerical recovery study."""
